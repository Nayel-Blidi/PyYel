"""
Networks packages initializer
"""